# 🚀 快速部署指南

## 5分钟快速部署（Linux/macOS）

```bash
# 1. 安装Docker（如果未安装）
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 2. 克隆项目
git clone <your-repo-url>
cd agent-management

# 3. 配置环境变量
cp .env.example .env
vim .env  # 编辑必填配置项

# 4. 一键部署
chmod +x deploy.sh
./deploy.sh install

# 5. 访问应用
# 浏览器打开: http://localhost:5000
```

## 5分钟快速部署（Windows）

```cmd
# 1. 安装Docker Desktop
# 下载: https://www.docker.com/products/docker-desktop

# 2. 克隆项目
git clone <your-repo-url>
cd agent-management

# 3. 配置环境变量
copy .env.example .env
notepad .env  # 编辑必填配置项

# 4. 一键部署
deploy.bat install

# 5. 访问应用
# 浏览器打开: http://localhost:5000
```

## ⚠️ 必填配置项

编辑 `.env` 文件，至少填写以下配置：

```env
# 数据库
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/agent_management

# Coze对象存储
COZE_BUCKET_ENDPOINT_URL=https://your-bucket-endpoint.com
COZE_BUCKET_NAME=your-bucket-name
COZE_BUCKET_REGION=your-region
```

## 📖 详细文档

查看 [DEPLOYMENT.md](./DEPLOYMENT.md) 了解完整的部署说明。

## 🔧 常用命令

```bash
# 启动服务
./deploy.sh start

# 停止服务
./deploy.sh stop

# 查看日志
./deploy.sh logs

# 备份数据库
./deploy.sh backup

# 查看帮助
./deploy.sh help
```

## ❓ 遇到问题？

1. 检查Docker是否运行: `docker ps`
2. 查看服务日志: `./deploy.sh logs`
3. 查看详细文档: [DEPLOYMENT.md](./DEPLOYMENT.md)
